import { GoogleGenAI } from "@google/genai";
import { WeatherResponse } from "../types";

const apiKey = process.env.API_KEY || '';

// Initialize the Gemini API client
const ai = new GoogleGenAI({ apiKey });

export const fetchWeatherInfo = async (query: string): Promise<WeatherResponse> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please check your environment configuration.");
  }

  try {
    const model = "gemini-2.5-flash";
    const prompt = `Tell me about the current weather in ${query}. 
    Please provide:
    1. Current temperature and condition (sunny, rainy, etc.).
    2. Humidity and wind speed if available.
    3. A brief forecast for the next 3 days.
    
    Format the response clearly with headings or bullet points. Use emojis where appropriate to make it visual (e.g., ☀️, 🌧️, 🌡️).`;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        // Note: responseMimeType cannot be JSON when using googleSearch
      },
    });

    const text = response.text || "No weather information found.";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as any[] || [];

    return {
      text,
      groundingChunks,
    };
  } catch (error) {
    console.error("Error fetching weather data:", error);
    throw error;
  }
};