import React, { useState, useEffect, useCallback } from 'react';
import { SearchBar } from './components/SearchBar';
import { WeatherDisplay } from './components/WeatherDisplay';
import { fetchWeatherInfo } from './services/geminiService';
import { WeatherResponse, WeatherState } from './types';
import { CloudRain, Sun, Zap } from 'lucide-react';

const App: React.FC = () => {
  const [query, setQuery] = useState<string>('Bangkok');
  const [weatherData, setWeatherData] = useState<WeatherResponse | null>(null);
  const [status, setStatus] = useState<WeatherState>(WeatherState.IDLE);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = useCallback(async (searchQuery: string) => {
    setQuery(searchQuery);
    setStatus(WeatherState.LOADING);
    setError(null);
    setWeatherData(null);

    try {
      const data = await fetchWeatherInfo(searchQuery);
      setWeatherData(data);
      setStatus(WeatherState.SUCCESS);
    } catch (err) {
      setError("Failed to fetch weather information. Please try again later.");
      setStatus(WeatherState.ERROR);
    }
  }, []);

  // Initial search for Bangkok on mount
  useEffect(() => {
    handleSearch('Bangkok');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Run only once

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white selection:bg-cyan-500/30">
      
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150"></div>
        <div className="absolute top-[-10%] left-[-10%] w-[40rem] h-[40rem] bg-purple-600/20 rounded-full blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40rem] h-[40rem] bg-cyan-600/20 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-12 flex flex-col items-center min-h-screen">
        
        {/* Header */}
        <header className="text-center mb-12 animate-fade-in-down">
          <div className="inline-flex items-center justify-center p-3 mb-4 bg-slate-800/50 rounded-2xl border border-slate-700/50 backdrop-blur-md shadow-lg">
             <Sun className="w-8 h-8 text-yellow-400 mr-3 animate-spin-slow" style={{ animationDuration: '10s' }} />
             <CloudRain className="w-6 h-6 text-blue-400" />
          </div>
          <h1 className="text-5xl font-extrabold tracking-tight mb-3 text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-blue-200">
            SkyCast AI
          </h1>
          <p className="text-slate-400 text-lg max-w-lg mx-auto">
            Real-time weather intelligence powered by Gemini & Google Search.
          </p>
        </header>

        {/* Search */}
        <div className="w-full mb-8">
          <SearchBar 
            onSearch={handleSearch} 
            isLoading={status === WeatherState.LOADING} 
            initialValue="Bangkok"
          />
        </div>

        {/* Content Area */}
        <div className="w-full flex-1 flex flex-col items-center justify-start min-h-[400px]">
          {status === WeatherState.LOADING && (
            <div className="flex flex-col items-center justify-center mt-12 animate-pulse">
               <div className="relative w-20 h-20">
                 <div className="absolute inset-0 border-t-4 border-cyan-400 rounded-full animate-spin"></div>
                 <div className="absolute inset-2 border-t-4 border-purple-400 rounded-full animate-spin-reverse"></div>
               </div>
               <p className="mt-6 text-cyan-300 font-medium tracking-wide">Gathering atmospheric data...</p>
            </div>
          )}

          {status === WeatherState.ERROR && (
            <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-xl mt-8 text-center max-w-md backdrop-blur-sm">
              <Zap className="w-10 h-10 text-red-400 mx-auto mb-3" />
              <h3 className="text-xl font-bold text-red-200 mb-2">Connection Error</h3>
              <p className="text-red-300/80">{error}</p>
              <button 
                onClick={() => handleSearch(query)}
                className="mt-4 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded-lg transition-colors"
              >
                Try Again
              </button>
            </div>
          )}

          {status === WeatherState.SUCCESS && weatherData && (
            <WeatherDisplay data={weatherData} location={query} />
          )}

          {/* Initial State / Idle (Unlikely due to auto-search, but good for safety) */}
          {status === WeatherState.IDLE && (
            <div className="text-center mt-12 text-slate-500">
              <p>Enter a location to get started.</p>
            </div>
          )}
        </div>
        
        {/* Footer */}
        <footer className="mt-12 text-slate-500 text-sm font-medium">
          Powered by Gemini 2.5 Flash
        </footer>
      </div>
    </div>
  );
};

export default App;