import React, { useState, FormEvent } from 'react';
import { Search } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
  initialValue?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({ onSearch, isLoading, initialValue = '' }) => {
  const [query, setQuery] = useState(initialValue);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto relative z-10">
      <div className="relative group">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
        <div className="relative flex items-center bg-slate-800 rounded-lg p-1">
          <Search className="w-6 h-6 text-slate-400 ml-3" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Enter city or location (e.g., Bangkok, London)..."
            className="w-full bg-transparent text-white placeholder-slate-400 border-none outline-none focus:ring-0 px-4 py-3 text-lg"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !query.trim()}
            className={`mr-1 px-6 py-2 rounded-md font-medium text-white transition-all duration-200
              ${isLoading || !query.trim() 
                ? 'bg-slate-700 cursor-not-allowed text-slate-400' 
                : 'bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-500/30'
              }`}
          >
            {isLoading ? 'Scanning...' : 'Search'}
          </button>
        </div>
      </div>
    </form>
  );
};