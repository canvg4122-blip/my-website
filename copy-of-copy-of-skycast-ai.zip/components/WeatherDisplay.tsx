import React from 'react';
import { GroundingChunk } from '../types';
import { ExternalLink, CloudSun, Wind, Droplets } from 'lucide-react';

interface WeatherDisplayProps {
  data: {
    text: string;
    groundingChunks?: GroundingChunk[];
  };
  location: string;
}

export const WeatherDisplay: React.FC<WeatherDisplayProps> = ({ data, location }) => {
  // Function to process markdown-like text for simple bolding and lists
  // Since we can't use external markdown libraries, we do a basic pass
  const formatText = (text: string) => {
    return text.split('\n').map((line, index) => {
      // Heading detection (rough)
      if (line.startsWith('## ') || line.startsWith('**') && line.length < 50) {
        return <h3 key={index} className="text-xl font-bold text-cyan-300 mt-4 mb-2">{line.replace(/#/g, '').replace(/\*\*/g, '')}</h3>;
      }
      // List items
      if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
        return <li key={index} className="ml-4 mb-1 text-slate-200">{line.replace(/^[\*\-]\s/, '')}</li>;
      }
      // Empty lines
      if (line.trim() === '') {
        return <div key={index} className="h-2"></div>;
      }
      // Regular text
      return <p key={index} className="text-slate-300 mb-1 leading-relaxed">{line}</p>;
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-8 animate-fade-in">
      {/* Main Weather Card */}
      <div className="bg-slate-800/50 backdrop-blur-xl border border-slate-700 rounded-2xl p-8 shadow-2xl">
        <div className="flex items-center gap-3 mb-6 border-b border-slate-700 pb-4">
          <CloudSun className="w-8 h-8 text-yellow-400" />
          <h2 className="text-2xl font-bold text-white">Weather Report: <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-400 capitalize">{location}</span></h2>
        </div>

        <div className="prose prose-invert max-w-none">
            {formatText(data.text)}
        </div>

        {/* Decorative Elements based on content (mock visualization since data is unstructured text) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 pt-6 border-t border-slate-700/50">
           <div className="bg-slate-900/50 p-4 rounded-xl flex items-center justify-center gap-3 border border-slate-700/50">
              <div className="p-2 bg-blue-500/20 rounded-full">
                <CloudSun className="w-6 h-6 text-blue-400" />
              </div>
              <div className="text-sm text-slate-400">Real-time Data</div>
           </div>
           <div className="bg-slate-900/50 p-4 rounded-xl flex items-center justify-center gap-3 border border-slate-700/50">
              <div className="p-2 bg-purple-500/20 rounded-full">
                <Droplets className="w-6 h-6 text-purple-400" />
              </div>
              <div className="text-sm text-slate-400">Detailed Forecast</div>
           </div>
           <div className="bg-slate-900/50 p-4 rounded-xl flex items-center justify-center gap-3 border border-slate-700/50">
              <div className="p-2 bg-emerald-500/20 rounded-full">
                <Wind className="w-6 h-6 text-emerald-400" />
              </div>
              <div className="text-sm text-slate-400">Live Conditions</div>
           </div>
        </div>
      </div>

      {/* Sources Section */}
      {data.groundingChunks && data.groundingChunks.length > 0 && (
        <div className="mt-6 p-6 bg-slate-900/40 rounded-xl border border-slate-800">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
            <ExternalLink className="w-4 h-4" />
            Verified Sources
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {data.groundingChunks.map((chunk, idx) => {
              if (chunk.web) {
                return (
                  <a 
                    key={idx} 
                    href={chunk.web.uri} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-700 transition-colors border border-slate-700/50 hover:border-blue-500/30 group"
                  >
                    <div className="w-2 h-2 rounded-full bg-blue-500 group-hover:animate-pulse"></div>
                    <span className="text-sm text-slate-300 truncate font-medium group-hover:text-blue-300 transition-colors">{chunk.web.title}</span>
                  </a>
                );
              }
              return null;
            })}
          </div>
        </div>
      )}
    </div>
  );
};