export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface WeatherResponse {
  text: string;
  groundingChunks?: GroundingChunk[];
}

export enum WeatherState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}